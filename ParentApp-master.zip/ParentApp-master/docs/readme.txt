Iteration 1:
Delete Coin Flip History button implemented initially for testing.
This wasn't part of the requirements but since it was already there it can act as a bonus feature.

For Timeout Timer, user must complete the "Finish Setup" steps (user may skip all steps) in order for the notification ringtone to work.
User may find the "Finish Setup" page under Settings in the emulator ("Finish setting up your device").

For Timeout Timer, user must complete the "Finish Setup" steps (user may skip all steps) in order for the notification ringtone to work.
User may find the "Finish Setup" page under Settings in the emulator ("Finish setting up your device").

App compatible 4", 5", 6", and 10" screen sizes.

In reference to the timeout timer, sometimes the app lags and takes a few extra seconds for the notification to pop up when the timer finishes.

Style guide from Dr. Brian Fraser's CMPT276 Course Website:
https://opencoursehub.cs.sfu.ca/bfraser/grav-cms/cmpt276/course-info/styleguide