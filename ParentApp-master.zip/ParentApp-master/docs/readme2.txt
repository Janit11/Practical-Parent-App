Iteration 2:

Camera functionality on devices running API 27:
The first time user attempts to add a picture using the camera on the device, location permissions
causes a small error where any picture taken is not used, instead saved to the gallery.
Does not occur on any subsequent attempts to add a child's picture using the camera.

App compatible for 4", 5", 6", and 10" screen sizes.
